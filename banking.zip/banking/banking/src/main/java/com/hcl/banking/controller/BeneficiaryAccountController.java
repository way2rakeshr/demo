package com.hcl.banking.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.hcl.banking.dto.BeneficiaryAccountDto;
import com.hcl.banking.dto.AccountResponse;
import com.hcl.banking.service.BeneficiaryAccountService;
import com.hcl.banking.serviceimpl.BeneficiaryAccountServiceImpl;

public class BeneficiaryAccountController {

	BeneficiaryAccountService beneficiaryAccountService;
	ResponseEntity<AccountResponse>saveBeneficiary( @RequestBody BeneficiaryAccountDto beneficiaryAccountDto){
		return new ResponseEntity<>( beneficiaryAccountService.saveBeneficiary(beneficiaryAccountDto),HttpStatus.CREATED);
		
	}
}
