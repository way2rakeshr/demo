package com.hcl.banking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.banking.model.BeneficiaryAccount;

public interface BeneficiaryAccountRepository extends JpaRepository<BeneficiaryAccount, Long> {

}
