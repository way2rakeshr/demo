package com.hcl.banking.serviceimpl;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.hcl.banking.dto.AccountResponse;
import com.hcl.banking.dto.BeneficiaryAccountDto;
import com.hcl.banking.dto.UserResponse;
import com.hcl.banking.exception.UserException;
import com.hcl.banking.model.AccountRegistration;
import com.hcl.banking.model.BeneficiaryAccount;
import com.hcl.banking.repository.AccountRegistrationRepository;
import com.hcl.banking.repository.BeneficiaryAccountRepository;
import com.hcl.banking.service.BeneficiaryAccountService;

@Service
public class BeneficiaryAccountServiceImpl implements BeneficiaryAccountService {
	@Autowired
	BeneficiaryAccountRepository beneficiaryAccountRepository;
	@Autowired
	AccountRegistrationRepository accountRegistrationRepository;

	@Override
	public AccountResponse saveBeneficiary(BeneficiaryAccountDto beneficiaryAccountDto) {

		Optional<AccountRegistration> accountDetails = accountRegistrationRepository
				.findByAccountNumber(beneficiaryAccountDto.getFromAccountNo());
		Optional<AccountRegistration> payeeAccountNo = accountRegistrationRepository.findByAccountNumber(beneficiaryAccountDto.getFromAccountNo());
		if (!payeeAccountNo.isPresent()) {
			throw new UserException("payeeAccount doesnot exist");
		}
		BeneficiaryAccount beneficiaryAccount = new BeneficiaryAccount();

		BeanUtils.copyProperties(beneficiaryAccountDto, beneficiaryAccount);
		beneficiaryAccount.setAccountRegistration(accountDetails.get());

		beneficiaryAccountRepository.save(beneficiaryAccount);
		return new AccountResponse("successfully created beneficiary account", 200);
	}

}
