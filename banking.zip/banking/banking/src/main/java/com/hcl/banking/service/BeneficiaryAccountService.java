package com.hcl.banking.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.hcl.banking.dto.BeneficiaryAccountDto;
import com.hcl.banking.dto.AccountResponse;

public interface BeneficiaryAccountService {
	AccountResponse saveBeneficiary(BeneficiaryAccountDto beneficiaryAccountDto);

 

}
