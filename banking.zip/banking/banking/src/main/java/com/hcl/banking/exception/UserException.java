package com.hcl.banking.exception;

public class UserException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public UserException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
