package com.hcl.banking.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;


@Entity
public class BeneficiaryAccount {
	
	long	payee_id;	
	String	payee_name;	
	long payee_account_no;	
	String	branch;	
	String ifsc_code;	
	String	phone_no;	
	@ManyToOne
	@Column(name = "accountreg")
	AccountRegistration accountRegistration;
	
	public BeneficiaryAccount() {
		super();
	
	}
	public long getPayee_id() {
		return payee_id;
	}
	public void setPayee_id(long payee_id) {
		this.payee_id = payee_id;
	}
	public String getPayee_name() {
		return payee_name;
	}
	public void setPayee_name(String payee_name) {
		this.payee_name = payee_name;
	}
	public long getPayee_account_no() {
		return payee_account_no;
	}
	public void setPayee_account_no(long payee_account_no) {
		this.payee_account_no = payee_account_no;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getIfsc_code() {
		return ifsc_code;
	}
	public void setIfsc_code(String ifsc_code) {
		this.ifsc_code = ifsc_code;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public AccountRegistration getAccountRegistration() {
		return accountRegistration;
	}
	public void setAccountRegistration(AccountRegistration accountRegistration) {
		this.accountRegistration = accountRegistration;
	}
}
