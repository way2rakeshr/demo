package com.hcl.banking.dto;

public class BeneficiaryAccountDto {
	

	String	payee_name;	
	long payeeAccount_no;	
	String	branch;	
	String ifscCode;	
	String	phoneNo;	
	long fromAccountNo;
	public BeneficiaryAccountDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getPayee_name() {
		return payee_name;
	}
	public void setPayee_name(String payee_name) {
		this.payee_name = payee_name;
	}
	public long getPayeeAccount_no() {
		return payeeAccount_no;
	}
	public void setPayeeAccount_no(long payeeAccount_no) {
		this.payeeAccount_no = payeeAccount_no;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public long getFromAccountNo() {
		return fromAccountNo;
	}
	public void setFromAccountNo(long fromAccountNo) {
		this.fromAccountNo = fromAccountNo;
	}
	

}
