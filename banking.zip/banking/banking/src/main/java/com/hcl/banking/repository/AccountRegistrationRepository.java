package com.hcl.banking.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.banking.model.AccountRegistration;

public interface AccountRegistrationRepository extends JpaRepository<AccountRegistration, Long> {
Optional<AccountRegistration> findByAccountNumber(long accountNumber);
}
