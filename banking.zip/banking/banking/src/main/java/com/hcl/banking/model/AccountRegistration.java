package com.hcl.banking.model;

public class AccountRegistration {
	long accountId;
	long accountNumber;

}
